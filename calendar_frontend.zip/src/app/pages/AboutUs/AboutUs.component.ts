import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, type OnInit } from '@angular/core';
import { AuthService } from 'src/app/auth/Auth.service';
import { Message } from 'src/app/data/Message';

@Component({
  selector: 'app-about-us',
  standalone: true,
  imports: [
    CommonModule,
  ],
  templateUrl: './AboutUs.component.html',
  styleUrls: ['./AboutUs.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AboutUsComponent implements OnInit {

  message : Message = {title: "Errore di connessione col server", body: "Si è verificato un problema col server"};

  constructor(private auth: AuthService, private changeDetectorRef: ChangeDetectorRef){}

  ngOnInit(): void {
    this.auth.getAboutUsMessage().subscribe((result : Message)=>{
      this.message = result;
      this.changeDetectorRef.detectChanges();
    });
  }

}
