import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, type OnInit } from '@angular/core';

@Component({
  selector: 'app-logout-page',
  standalone: true,
  imports: [
    CommonModule,
  ],
  templateUrl: './LogoutPage.component.html',
  styleUrls: ['./LogoutPage.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LogoutPageComponent implements OnInit {

  ngOnInit(): void { }

}
