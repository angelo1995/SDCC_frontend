import { EventEmitter, Injectable } from '@angular/core';
import { DayOfWeek } from './weeklyCalendar/weeklyCalendar.component';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataTableService {

  data = new EventEmitter<DayOfWeek[]>();

  constructor() { }

  public produce(dataWeek: DayOfWeek[]): void {
    this.data.emit(dataWeek);
  }

  public consume(): Observable<DayOfWeek[]> {
    return this.data;
  }

}
