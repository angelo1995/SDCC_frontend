import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Inject, type OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { CdkListbox, CdkOption } from '@angular/cdk/listbox';
import { AuthService } from 'src/app/auth/Auth.service';

export interface MeetingDetail {
  date: Date;
  duration: number;
  priority: string;
  guests: string[];
  title: string;
  description: string;
}

@Component({
  selector: 'app-meeting-detail',
  standalone: true,
  imports: [
    CommonModule,
    MatFormFieldModule,
    MatInputModule,
    FormsModule,
    MatButtonModule,
    MatDialogModule,
    MatSelectModule,
    MatGridListModule,
    CdkListbox,
    CdkOption,
  ],
  templateUrl: './MeetingDetail.component.html',
  styleUrl: './MeetingDetail.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MeetingDetailComponent implements OnInit {

  meetingDetail : MeetingDetail = {
    date: new Date(),
    duration: -1,
    priority: "media",
    guests: ["invitato 1", "invitato 2", "invitato 3", "invitato 4", "invitato 5", "invitato 6"],
    title: "Titolo",
    description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec lorem leo, consequat non augue eget, vehicula vestibulum neque. Cras sed tristique enim. Aliquam eu ornare elit. Donec nec feugiat enim, quis pretium elit."
  };

  constructor(
    private auth: AuthService,
    private changeDetectorRef: ChangeDetectorRef,
    public dialogRef: MatDialogRef<MeetingDetailComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {id: number},
  ) {}

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    this.auth.viewMeetingDetail(this.data.id).subscribe((response : any)=>{
      this.meetingDetail = response;

      // Aggiungi l'offset del fuso orario locale
      const day = new Date(this.meetingDetail.date);
      const timezoneOffset = day.getTimezoneOffset() * 60000;
      const localTime = new Date(day.getTime() + timezoneOffset);
      this.meetingDetail.date = localTime;

      this.changeDetectorRef.detectChanges();
      console.log("dettaglio");
      console.log(response);
    });
  }

}
