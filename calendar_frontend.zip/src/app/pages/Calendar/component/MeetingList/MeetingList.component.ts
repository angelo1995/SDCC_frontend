import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Inject, NgModule, type OnInit } from '@angular/core';
import {
  MAT_DIALOG_DATA,
  MatDialogRef,
  MatDialogModule,
  MatDialog,
  MatDialogConfig,
} from '@angular/material/dialog';
import {MatButtonModule} from '@angular/material/button';
import {FormsModule} from '@angular/forms';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatSelectModule} from '@angular/material/select';
import {MatGridListModule} from '@angular/material/grid-list';
import { MatChipsModule } from '@angular/material/chips';
import { MatIconModule } from '@angular/material/icon';
import {CdkListbox, CdkOption} from '@angular/cdk/listbox';
import { AuthService } from 'src/app/auth/Auth.service';
import { MeetingDetailComponent } from '../MeetingDetail/MeetingDetail.component';
import { BookingFormComponent } from '../bookingForm/bookingForm.component';
import { ComponentType } from '@angular/cdk/portal';
import { ViewMeeting } from 'src/app/data/viewMeeting';
import { BookingData } from 'src/app/data/BookingData';
import { DialogData } from 'src/app/data/DialogData';
import { MatSnackBar } from '@angular/material/snack-bar';

export interface SlotData{
  date: Date;
}

@Component({
  selector: 'app-meeting-list',
  standalone: true,
  imports: [
    CommonModule,
    MatFormFieldModule,
    MatInputModule,
    FormsModule,
    MatButtonModule,
    MatDialogModule,
    MatSelectModule,
    MatGridListModule,
    MatChipsModule,
    MatIconModule,
    CdkListbox,
    CdkOption,
  ],
  templateUrl: './MeetingList.component.html',
  styleUrl: './MeetingList.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MeetingListComponent implements OnInit {

  meetings : ViewMeeting[] = [
    {id: 1, title: 'Rat'},
    {id: 2, title: 'Ox'},
    {id: 3, title: 'Tiger'},
    {id: 4, title: 'Rabbit'},
    {id: 5, title: 'Dragon'},
    {id: 6, title: 'Snake'},
    {id: 7, title: 'Horse'},
    {id: 8, title: 'Goat'},
    {id: 9, title: 'Monkey'},
    {id: 10, title: 'Rooster'},
    {id: 11, title: 'Dog'},
    {id: 12, title: 'Pig'},
  ];

  constructor(
    public dialogRef: MatDialogRef<MeetingListComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    private auth: AuthService,
    public dialog: MatDialog,
    private _snackBar: MatSnackBar,
    private changeDetectorRef: ChangeDetectorRef,
  ) {}

  ngOnInit(): void {

    const day = new Date(this.data.day);
    const timezoneOffset = day.getTimezoneOffset() * 60000;
    const localTime = new Date(day.getTime() - timezoneOffset);

    const body : SlotData = { date: localTime };
    this.auth.viewMeetingsSlot(body).subscribe((result : ViewMeeting[])=>{
      this.meetings = result;
      this.changeDetectorRef.detectChanges();
    });

  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  create(): void {
    const component = BookingFormComponent;
    this.openDialog(component, 0);
  }

  viewMeetingDetail(id : number): void {
    console.log("id lista: " + id);
    const component = MeetingDetailComponent;
    this.openDialog(component, id);
  }

  openDialog(component: ComponentType<unknown>, id : number): void {

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data = {id: id, date : this.data.day};

    const dialogRef = this.dialog.open(component, dialogConfig);

    dialogRef.afterClosed().subscribe((result : BookingData) => {
      console.log('form closed');
      //console.log("result=", result);
      if(result === undefined){
        //console.log('lista chiusa');
        return;
      }

      console.log("risultato prenotazione", result);
      this.auth.bookingMeeting(result).subscribe((response : any) =>{
        console.log("risposta prenotazione", response);
        this.openSnackBar(response.message, "ok", 5500);
        if(response.success === true){
          console.log("successo");
          this.data.duration = result.duration;
          this.data.success = true;
          this.data.message = response.message;
          this.meetings.push({id: response.meeting.id, title: response.meeting.title});
          this.changeDetectorRef.detectChanges();
        }
      });
    });
  }

  private openSnackBar(message: string, action: string, durationInMillisecond?: number) {
    if(durationInMillisecond === undefined){
      this._snackBar.open(message, action);
    }
    this._snackBar.open(message, action, {
      duration: durationInMillisecond,
    });
  }

}
