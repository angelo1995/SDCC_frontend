import { AsyncPipe, CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, Inject, type OnInit } from '@angular/core';
import {
  MAT_DIALOG_DATA,
  MatDialogRef,
  MatDialogModule,
} from '@angular/material/dialog';
import {MatButtonModule} from '@angular/material/button';
import {FormBuilder, FormsModule, NgForm, ReactiveFormsModule} from '@angular/forms';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatSelectModule} from '@angular/material/select';
import {MatGridListModule} from '@angular/material/grid-list';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { Observable, } from 'rxjs';
import {startWith, map} from 'rxjs/operators';
import { CdkListbox, CdkOption } from '@angular/cdk/listbox';
import { ViewMeeting } from 'src/app/data/viewMeeting';
import { AuthService } from 'src/app/auth/Auth.service';
import { BookingData } from 'src/app/data/BookingData';

export interface StateGroup {
  letter: string;
  meetings: ViewMeeting[];
}

export const _filter = (opt: ViewMeeting[], value: string): ViewMeeting[] => {
  const filterValue = value.toLowerCase();
  return opt.filter(item => item.title.toLowerCase().includes(filterValue));
};

@Component({
  selector: 'app-booking-form',
  standalone: true,
  imports: [
    CommonModule,
    MatFormFieldModule,
    MatInputModule,
    FormsModule,
    MatButtonModule,
    MatDialogModule,
    MatSelectModule,
    MatGridListModule,

    ReactiveFormsModule,
    MatAutocompleteModule,
    AsyncPipe,

    CdkListbox,
    CdkOption,
  ],
  templateUrl: './bookingForm.component.html',
  styleUrls: ['./bookingForm.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BookingFormComponent implements OnInit {

  durations = [1, 2, 3, 4];
  priorities = ["bassa", "media", "alta",];

  meetings : ViewMeeting[] = [];

  constructor(
    public dialogRef: MatDialogRef<BookingFormComponent>,
    @Inject(MAT_DIALOG_DATA) public data: BookingData,
    private _formBuilder: FormBuilder,
    private auth: AuthService,
  ) {}

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    this.data.duration = 1;
    this.data.priority = "media";

    this.auth.viewAllCostumer().subscribe((result : any)=>{
      console.log("lista dei membri", result);
      this.stateGroups = result;

      this.stateGroupOptions = this.stateForm.get('stateGroup')!.valueChanges.pipe(
        startWith(''),
        map((value: string | null) => this._filterGroup(value || '')),
      );
    });

  }

  stateForm = this._formBuilder.group({
    stateGroup: '',
  });

  stateGroups: StateGroup[] = [
    {
      letter: 'A',
      meetings: [
        {id: 0, title: 'Alabama'},
        {id: 1, title: 'Alaska'},
        {id: 2, title: 'Arizona'},
        {id: 3, title: 'Arkansas'},
      ],
    },
    {
      letter: 'C',
      meetings: [
        {id: 0, title: 'California'},
        {id: 1, title: 'Colorado'},
        {id: 2, title: 'Connecticut'},
      ],
    },
    {
      letter: 'D',
      meetings: [
        {id: 0, title: 'Delaware'},
      ],
    },
    {
      letter: 'F',
      meetings: [
        {id: 0, title: 'Florida'},
      ],
    },
    {
      letter: 'G',
      meetings: [
        {id: 0, title: 'Georgia'},
      ],
    },
    {
      letter: 'H',
      meetings: [
        {id: 0, title: 'Hawaii'},
      ],
    },
    {
      letter: 'I',
      meetings: [
        {id: 0, title: 'Idaho'},
        {id: 1, title: 'Illinois'},
        {id: 2, title: 'Indiana'},
        {id: 3, title: 'Iowa'},
      ],
    },
    {
      letter: 'K',
      meetings: [
        {id: 0, title: 'Kansas'},
        {id: 1, title: 'Kentucky'},
      ],
    },
    {
      letter: 'L',
      meetings: [
        {id: 0, title: 'Louisiana'},
      ],
    },
    {
      letter: 'M',
      meetings: [
        {id: 0, title: 'Maine'},
        {id: 1, title: 'Maryland'},
        {id: 2, title: 'Massachusetts'},
        {id: 3, title: 'Michigan'},
        {id: 3, title: 'Minnesota'},
        {id: 3, title: 'Mississippi'},
        {id: 3, title: 'Missouri'},
        {id: 3, title: 'Montana'},
      ],
    },
    {
      letter: 'N',
      meetings: [
        {id: 0, title: 'Nebraska'},
        {id: 1, title: 'Nevada'},
        {id: 2, title: 'New Hampshire'},
        {id: 3, title: 'New Jersey'},
        {id: 3, title: 'New Mexico'},
        {id: 3, title: 'New York'},
        {id: 3, title: 'North Carolina'},
        {id: 3, title: 'North Dakota'},
      ],
    },
    {
      letter: 'O',
      meetings: [
        {id: 0, title: 'Ohio'},
        {id: 1, title: 'Oklahoma'},
        {id: 2, title: 'Oregon'},
      ],
    },
    {
      letter: 'P',
      meetings: [
        {id: 0, title: 'Pennsylvania'},
      ],
    },
    {
      letter: 'R',
      meetings: [
        {id: 0, title: 'Rhode Island'},
      ],
    },
    {
      letter: 'S',
      meetings: [
        {id: 0, title: 'South Carolina'},
        {id: 1, title: 'South Dakota'},
      ],
    },
    {
      letter: 'T',
      meetings: [
        {id: 0, title: 'Tennessee'},
        {id: 1, title: 'Texas'},
      ],
    },
    {
      letter: 'U',
      meetings: [
        {id: 0, title: 'Utah'},
      ],
    },
    {
      letter: 'V',
      meetings: [
        {id: 0, title: 'Vermont'},
        {id: 1, title: 'Virginia'},
      ],
    },
    {
      letter: 'W',
      meetings: [
        {id: 0, title: 'Washington'},
        {id: 1, title: 'West Virginia'},
        {id: 2, title: 'Wisconsin'},
        {id: 3, title: 'Wyoming'},
      ],
    },
  ];

  stateGroupOptions!: Observable<StateGroup[]>;

  private _filterGroup(value: string): StateGroup[] {
    if (value) {
      return this.stateGroups
        .map(group => ({letter: group.letter, meetings: _filter(group.meetings, value)}))
        .filter(group => group.meetings.length > 0);
    }
    return this.stateGroups;
  }

  addToList(name: ViewMeeting): void {
    console.log("opzione", name);
    this.stateForm.reset();
    const index: number = this.meetings.findIndex((m => {return m === name;}));
    if(index === -1){
      this.meetings.push(name);
    }

  }

  removeFromList(meeting: ViewMeeting): void {
    const index: number = this.meetings.indexOf(meeting);
    if (index !== -1) {
        this.meetings.splice(index, 1);
    }
  }

  onBookClick(): void {
    const id_list : number[] = this.meetings.map(c => c.id);
    this.data.guests = id_list;
    console.log("prenotazione", this.data);
    //this.auth.bookingMeeting(this.data).subscribe();
  }

}
