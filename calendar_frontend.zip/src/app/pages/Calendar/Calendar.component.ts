import { CommonModule, DatePipe } from '@angular/common';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DoCheck, type OnInit } from '@angular/core';
import {MatTableModule} from '@angular/material/table';
import { DayOfWeek, WeeklyCalendarComponent } from "./component/weeklyCalendar/weeklyCalendar.component";
import {MatChipsModule} from '@angular/material/chips';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { AuthService } from 'src/app/auth/Auth.service';
import { DataTableService } from './component/DataTable.service';

interface month {
  value: number;
  viewValue: string;
}

const MONTHS : month[] = [
  {value: 0, viewValue: "gennaio"},
  {value: 1, viewValue: "febbraio"},
  {value: 2, viewValue: "marzo"},
  {value: 3, viewValue: "aprile"},
  {value: 4, viewValue: "maggio"},
  {value: 5, viewValue: "giugno"},
  {value: 6, viewValue: "luglio"},
  {value: 7, viewValue: "agosto"},
  {value: 8, viewValue: "settembre"},
  {value: 9, viewValue: "ottobre"},
  {value: 10, viewValue: "novembre"},
  {value: 11, viewValue: "dicembre"},
];

interface Interval {
  weeks: DayOfWeek[][];
}

@Component({
    selector: 'app-calendar',
    standalone: true,
    templateUrl: './Calendar.component.html',
    styleUrls: ['./Calendar.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    imports: [
        CommonModule,
        MatTableModule,
        WeeklyCalendarComponent,
        MatChipsModule,
        MatIconModule,
        MatFormFieldModule,
        MatSelectModule,
        MatInputModule,
        FormsModule
    ]
})
export class CalendarComponent implements OnInit {

  day : Date = new Date("2024-01-15");

  months = MONTHS;

  month : number = 0;

  interval : Interval = {weeks: []};
  dataWeek: DayOfWeek[] = [];

  infDay : Date = new Date("2024-01-15");
  supDay : Date = new Date("2024-01-20");
  windowSize : number = 4;
  index : number = 0;

  constructor(private auth: AuthService, private dataService: DataTableService, private datePipe : DatePipe){}

  ngOnInit(): void {
    this.thisWeek();
    /*this.month = this.day.getMonth();
    this.supDay = new Date(this.infDay.getTime() + this.windowSize*(7*24*60*60*1000));
    this.update(this.infDay, this.supDay);*/
  }

  forward(): void {
    const newDay = this.day.getTime() + (7*24*60*60*1000);
    this.day = new Date(newDay);
    this.month = this.day.getMonth();
    this.index = (this.index + 1) % this.windowSize;
    if(this.day.getTime() > this.supDay.getTime()){
      this.infDay = new Date(this.day.getTime());
      this.supDay = new Date(this.infDay.getTime() + (this.windowSize*7 - 2)*(24*60*60*1000));
      const infString = this.datePipe.transform(this.infDay, 'dd/MM/yyyy');
      const supString = this.datePipe.transform(this.supDay, 'dd/MM/yyyy');
      console.log("inf", infString, "sup", supString);
      this.update(this.infDay, this.supDay);
    } else {
      this.dataWeek = this.interval.weeks[this.index];
      this.dataService.produce(this.dataWeek);
    }
  }

  backward(): void {
    const newDay = this.day.getTime() - (7*24*60*60*1000);
    this.day = new Date(newDay);
    this.month = this.day.getMonth();
    this.index = (this.index - 1 >= 0) ? this.index - 1 : this.windowSize-1;
    console.log("index", this.index);
    if(this.day.getTime() < this.infDay.getTime()){
      this.infDay = new Date(this.day.getTime() - (this.windowSize - 1)*(7*24*60*60*1000));
      this.supDay = new Date(this.infDay.getTime() + (this.windowSize*7 - 2)*(24*60*60*1000));
      this.update(this.infDay, this.supDay);
    } else {
      this.dataWeek = this.interval.weeks[this.index];
      this.dataService.produce(this.dataWeek);
    }
  }

  private moveWeek(): void{
    this.month = this.day.getMonth();
    if(this.day.getTime() > this.supDay.getTime()){
      this.infDay = new Date(this.day.getTime());
      this.supDay = new Date(this.infDay.getTime() + (this.windowSize*7 - 2)*(24*60*60*1000));
      this.update(this.infDay, this.supDay);
      return;
    }
    if(this.day.getTime() < this.infDay.getTime()){
      this.infDay = new Date(this.day.getTime() - (this.windowSize - 1)*(7*24*60*60*1000));
      this.supDay = new Date(this.infDay.getTime() + (this.windowSize*7 - 2)*(24*60*60*1000));
      this.update(this.infDay, this.supDay);
      return;
    }
    this.dataWeek = this.interval.weeks[this.index];
    this.dataService.produce(this.dataWeek);
  }

  thisWeek(): void {
    const today = new Date();
    /*const offset = (today.getDay()-1)*24*60*60*1000;
    this.day = new Date(today.getTime() - offset);
    this.month = this.day.getMonth();*/
    this.resetTo(today);
  }

  setMonth(value: number): void{
    /*this.day.setMonth(value);
    this.day.setDate(10);
    const offset = (this.day.getDay()-1)*24*60*60*1000;
    this.day = new Date(this.day.getTime() - offset);
    this.index = 0;
    this.infDay = new Date(this.day.getTime());
    this.supDay = new Date(this.infDay.getTime() + (this.windowSize*7 - 2)*(24*60*60*1000));
    this.update(this.infDay, this.supDay);*/
    const day = new Date(this.day.getTime());
    day.setMonth(value);
    day.setDate(10);
    this.resetTo(day);
  }

  private resetTo(day: Date): void {
    const offset = (day.getDay()-1)*24*60*60*1000;
    this.day = new Date(day.getTime() - offset);
    this.index = 0;
    this.month = this.day.getMonth();
    this.infDay = new Date(this.day.getTime());
    this.supDay = new Date(this.infDay.getTime() + (this.windowSize*7 - 2)*(24*60*60*1000));
    this.update(this.infDay, this.supDay);
  }

  private update(start: Date, end: Date): void {
    this.auth.viewBookingWindow(start, end).subscribe((result : any) => {
      this.mapDayofWeek(result);
      console.log("update", this.interval);
    });
  }

  private mapDayofWeek(interval: any): void {
    this.interval.weeks = [];
    let week = [];
    let row : DayOfWeek = {position: -1, hour: '', monday: '', tuesday: '', wednesday: '', thursday: '', friday: '', saturday: ''};
    for(let j : number = 0; j < interval.weeks.length; j++){
      week = [];
      for(let i : number = 0; i < 11; i++){
        row = {
          position: i,
          hour: (i+8)+':00',
          monday: interval.weeks[j][i].monday,
          tuesday: interval.weeks[j][i].tuesday,
          wednesday: interval.weeks[j][i].wednesday,
          thursday: interval.weeks[j][i].thursday,
          friday: interval.weeks[j][i].friday,
          saturday: interval.weeks[j][i].saturday
        };
        week.push(row);
      }
      this.interval.weeks.push(week);
    }
    this.dataWeek = this.interval.weeks[this.index];
    this.dataService.produce(this.dataWeek);
  }

}
