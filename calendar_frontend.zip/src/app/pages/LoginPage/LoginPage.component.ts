import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, type OnInit } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import {MatInputModule} from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';
import { FormsModule, NgForm } from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from 'src/app/auth/Auth.service';
import { Observable } from 'rxjs';
import { LoginBody } from 'src/app/data/LoginBody';

@Component({
  selector: 'app-login-page',
  standalone: true,
  imports: [
    CommonModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    MatButtonModule,
    FormsModule,
    MatIconModule,
    RouterModule,
  ],
  templateUrl: './LoginPage.component.html',
  styleUrls: ['./LoginPage.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LoginPageComponent implements OnInit {

  constructor(private auth: AuthService, private router: Router){}

  hide = true;

  ngOnInit(): void { }

  onSubmit(form: NgForm){
    /*const email = form.value.email;
    const password = form.value.password;
    const body : LoginBody = {
      email: email,
      password: password
    };
    console.log(email, password);
    this.auth.login(body).subscribe((message) => {
      console.log(message);
      if(message.success){
        this.router.navigateByUrl('/home');
      }
    });*/
  }

}
