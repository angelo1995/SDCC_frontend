import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, type OnInit } from '@angular/core';
import { AuthService } from 'src/app/auth/Auth.service';
import { Message } from 'src/app/data/Message';
import { LineComponent } from "./line/line.component";

@Component({
    selector: 'app-home',
    standalone: true,
    templateUrl: './Home.component.html',
    styleUrls: ['./Home.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    imports: [
    CommonModule,
    LineComponent
]
})
export class HomeComponent implements OnInit {

  message : Message = {title: "Errore di connessione col server", body: "Si è verificato un problema col server"};

  constructor(private auth: AuthService, private changeDetectorRef: ChangeDetectorRef){}

  ngOnInit(): void {
    this.auth.getHomeMessage().subscribe((result : Message)=>{
      this.message = result;
      this.changeDetectorRef.detectChanges();
    });
  }

}
