import { CommonModule } from '@angular/common';
import { AfterContentInit, ChangeDetectionStrategy, Component, type OnInit } from '@angular/core';

interface star {
  x: number,
  y: number,
  radius: number,
  vx: number,
  vy: number,
};

@Component({
  selector: 'app-line',
  standalone: true,
  imports: [
    CommonModule,
  ],
  templateUrl: './line.component.html',
  styleUrl: './line.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LineComponent implements OnInit, AfterContentInit {

  // canvas = document.getElementById("canvas");
  canvas! : HTMLCanvasElement;
  ctx : any;
  stars : star[] = []; // Array that contains the stars
  FPS = 60; // Frames per second
  x = 100; // Number of stars
  mouse: { x: number; y: number } = {
    x: 0,
    y: 0,
  }; // mouse location

  constructor() {
    debugger;
  }

  ngOnInit() {
    this.canvas = document.getElementById('canvas') as HTMLCanvasElement;
    this.ctx = this.canvas.getContext('2d');
    console.log(this.canvas);
  }

  // Draw the scene
  draw() {
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

    this.ctx.globalCompositeOperation = 'lighter';

    for (var i = 0, x = this.stars.length; i < x; i++) {
      var s = this.stars[i];

      this.ctx.fillStyle = '#00e6ff';
      this.ctx.beginPath();
      this.ctx.arc(s.x, s.y, s.radius, 0, 2 * Math.PI);
      this.ctx.fill();
      this.ctx.fillStyle = 'black';
      this.ctx.stroke();
    }

    this.ctx.beginPath();
    for (var i = 0, x = this.stars.length; i < x; i++) {
      var starI = this.stars[i];
      this.ctx.moveTo(starI.x, starI.y);
      if (this.distance(this.mouse, starI) < 150)
        this.ctx.lineTo(this.mouse.x, this.mouse.y);
      for (var j = 0, x = this.stars.length; j < x; j++) {
        var starII = this.stars[j];
        if (this.distance(starI, starII) < 150) {
          //ctx.globalAlpha = (1 / 150 * distance(starI, starII).toFixed(1));
          this.ctx.lineTo(starII.x, starII.y);
        }
      }
    }
    this.ctx.lineWidth = 0.25;
    this.ctx.strokeStyle = '#00e6ff';
    this.ctx.stroke();
  }

  distance(point1: any, point2: any) {
    var xs = 0;
    var ys = 0;

    xs = point2.x - point1.x;
    xs = xs * xs;

    ys = point2.y - point1.y;
    ys = ys * ys;

    return Math.sqrt(xs + ys);
  }

  // Update star locations

  update() {
    for (var i = 0, x = this.stars.length; i < x; i++) {
      var s = this.stars[i];

      s.x += s.vx / this.FPS;
      s.y += s.vy / this.FPS;

      if (s.x < 0 || s.x > this.canvas.width) s.vx = -s.vx;
      if (s.y < 0 || s.y > this.canvas.height) s.vy = -s.vy;
    }
  }

  // Update and draw

  tick = () => {
    if (this && this.draw != undefined) {
      this.draw();
      this.update();
    }
    console.log(this.tick);
    requestAnimationFrame(this.tick);
  };

  ngAfterContentInit() {
    this.canvas.width = window.innerWidth;
    this.canvas.height = window.innerHeight;
    for (var i = 0; i < this.x; i++) {
      this.stars.push({
        x: Math.random() * this.canvas.width,
        y: Math.random() * this.canvas.height,
        radius: Math.random() * 1 + 1,
        vx: Math.floor(Math.random() * 50) - 25,
        vy: Math.floor(Math.random() * 50) - 25,
      });
    }
    this.canvas.addEventListener('mousemove', (e) => {
      this.mouse.x = e.clientX;
      this.mouse.y = e.clientY;
    });
    this.tick();
  }

}
