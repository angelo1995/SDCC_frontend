import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, type OnInit } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MAT_DATE_LOCALE, provideNativeDateAdapter } from '@angular/material/core';
import { OccasionCreationInterface } from 'src/app/data/OccasionCreationInterface';
import { AuthService } from 'src/app/auth/Auth.service';

interface Hour {
  value: number;
  viewValue: string;
}

interface Data {
  title: string;
  description: string;
  date: Date;
  price: number;
  time: number;
  duration: number;
}

const ONE_HOUR_IN_MILLIS = 60*60*1000;

@Component({
  selector: 'app-generate-occasion',
  standalone: true,
  providers: [provideNativeDateAdapter(), { provide: MAT_DATE_LOCALE, useValue: 'en-GB' }],
  imports: [
    CommonModule,
    MatButtonModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    MatButtonModule,
    FormsModule,
    MatIconModule,
    MatDatepickerModule,
  ],
  templateUrl: './GenerateOccasion.component.html',
  styleUrl: './GenerateOccasion.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class GenerateOccasionComponent implements OnInit {

  hide : boolean = false;

  data : Data = {title: "", description: "", date: new Date(), price: 10, time: -1, duration: -1};

  hours: Hour[] = [
    {value: 8, viewValue: "08:00"},  {value: 9, viewValue: "09:00"},
    {value: 10, viewValue: "10:00"}, {value: 11, viewValue: "11:00"},
    {value: 12, viewValue: "12:00"}, {value: 13, viewValue: "13:00"},
    {value: 14, viewValue: "14:00"}, {value: 15, viewValue: "15:00"},
    {value: 16, viewValue: "16:00"}, {value: 17, viewValue: "17:00"},
    {value: 18, viewValue: "18:00"},
  ];

  durations: Hour[] = [
    {value: 1, viewValue: "1"},  {value: 2, viewValue: "2"},
    {value: 3, viewValue: "3"}, {value: 4, viewValue: "4"},
  ];

  constructor(private auth: AuthService){}

  ngOnInit(): void { }

  onSubmit(): void {
    const date = this.data.date.getTime();
    const newDate = new Date(date+this.data.time*ONE_HOUR_IN_MILLIS);
    const message : OccasionCreationInterface= {
      title: this.data.title, description: this.data.description, date: newDate,
      price: this.data.price, duration: this.data.duration
    }
    console.log(message);
    this.auth.createOccasion(message).subscribe((result : any)=>{
      console.log(result);
    });
  }

}
