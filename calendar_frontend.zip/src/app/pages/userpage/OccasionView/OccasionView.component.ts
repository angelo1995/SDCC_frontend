import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, type OnInit } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { AuthService } from 'src/app/auth/Auth.service';

@Component({
  selector: 'app-occasion-view',
  standalone: true,
  imports: [
    CommonModule,
    MatButtonModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    MatButtonModule,
    FormsModule,
    MatIconModule,
  ],
  templateUrl: './OccasionView.component.html',
  styleUrl: './OccasionView.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OccasionViewComponent implements OnInit {

  data : any[] = [];

  constructor(private auth: AuthService, private changeDetectorRef: ChangeDetectorRef){}

  ngOnInit(): void {
    this.auth.viewAllOccasionAdmin().subscribe((result : any)=>{
      console.log(result);
      this.data = result;
      this.changeDetectorRef.detectChanges();
    });
  }

  onDelete(item: any): void {
    console.log(item);
    this.auth.deleteOccasion(item.id).subscribe((result : any)=>{
      console.log(result);
      if(result === true){
        const index : number = this.data.indexOf(item);
        this.data.splice(index, 1);
        this.changeDetectorRef.detectChanges();
      }
    });
  }

}
