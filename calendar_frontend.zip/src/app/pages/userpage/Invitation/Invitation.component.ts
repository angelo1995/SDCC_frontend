import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, type OnInit } from '@angular/core';
import { AuthService } from 'src/app/auth/Auth.service';
import { MeetingData } from 'src/app/data/MeetingData';
import { Button, SingleReservationComponent } from "../ReservationView/SingleReservation/SingleReservation.component";
import { DETAIL_COLOR, PRIMARY_COLOR, WARN_COLOR } from 'src/app/data/Color';
import { ComponentType } from '@angular/cdk/portal';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { BookingData } from 'src/app/data/BookingData';
import { MeetingDetailComponent } from '../../Calendar/component/MeetingDetail/MeetingDetail.component';

@Component({
    selector: 'app-invitation',
    standalone: true,
    templateUrl: './Invitation.component.html',
    styleUrl: './Invitation.component.css',
    changeDetection: ChangeDetectionStrategy.OnPush,
    imports: [
        CommonModule,
        SingleReservationComponent
    ]
})
export class InvitationComponent implements OnInit {

  data : MeetingData[] = [];

  buttons : Button[] = [
    {name: "conferma", action: "accept", color: PRIMARY_COLOR},
    {name: "dettagli", action: "detail", color: DETAIL_COLOR},
    {name: "rifiuta", action: "refuse", color: WARN_COLOR},
  ];

  buttonsCancelled : Button[] = [
    {name: "dettagli", action: "detail", color: DETAIL_COLOR},
    {name: "cancella", action: "delete", color: WARN_COLOR},
  ];

  constructor(private auth: AuthService, public dialog: MatDialog, private changeDetectorRef: ChangeDetectorRef){}

  ngOnInit(): void {
      this.auth.viewUserInvitations().subscribe((result : MeetingData[])=>{
        console.log("inviti", result);
        this.data = result;
        this.changeDetectorRef.detectChanges();
      });
  }

  action(action : string, item: MeetingData): void {
    /*if(action === "delete"){
      const index : number = this.data.indexOf(item);
      this.data.splice(index, 1);
      this.changeDetectorRef.detectChanges();
    }*/

      if(action === "detail"){
        this.openDialog(MeetingDetailComponent, item.id);
      }
      if(action === "accept"){
        this.auth.invitationAccept(item.id).subscribe((result : boolean)=>{
          if(result === true){
            const index : number = this.data.indexOf(item);
            this.data.splice(index, 1);
            this.changeDetectorRef.detectChanges();
          }
        });
      }

      if(action === "refuse"){
        this.auth.invitationRefuse(item.id).subscribe((result : boolean)=>{
          if(result === true){
            const index : number = this.data.indexOf(item);
            this.data.splice(index, 1);
            this.changeDetectorRef.detectChanges();
          }
        });
      }

      if(action === "delete"){
        this.auth.deleteMeeting(item.id).subscribe((result : any)=>{
          console.log(result);
          if(result === true){
            const index : number = this.data.indexOf(item);
            this.data.splice(index, 1);
            this.changeDetectorRef.detectChanges();
          }
        });
      }
  }

  openDialog(component: ComponentType<unknown>, id : number): void {

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data = {id: id};

    const dialogRef = this.dialog.open(component, dialogConfig);

    dialogRef.afterClosed().subscribe((result : BookingData) => {
      console.log('form closed');
      //console.log("result=", result);
      if(result === undefined){
        //console.log('lista chiusa');
        return;
      }
    });
  }

}
