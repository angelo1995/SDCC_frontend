import { ComponentType } from '@angular/cdk/portal';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, type OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { AuthService } from 'src/app/auth/Auth.service';
import { BookingData } from 'src/app/data/BookingData';
import { DETAIL_COLOR } from 'src/app/data/Color';
import { MeetingData } from 'src/app/data/MeetingData';
import { MeetingDetailComponent } from '../../Calendar/component/MeetingDetail/MeetingDetail.component';
import { Button, SingleReservationComponent } from "../ReservationView/SingleReservation/SingleReservation.component";

@Component({
  selector: 'app-refuse-invitation',
  standalone: true,
  imports: [
    CommonModule,
    SingleReservationComponent,
  ],
  templateUrl: './RefuseInvitation.component.html',
  styleUrl: './RefuseInvitation.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RefuseInvitationComponent implements OnInit {

  data : MeetingData[] = [];

  buttons : Button[] = [
    {name: "dettagli", action: "detail", color: DETAIL_COLOR},
  ];

  constructor(private auth: AuthService, public dialog: MatDialog, private changeDetectorRef: ChangeDetectorRef){}

  ngOnInit(): void {
      this.auth.viewUserInvitationsRefused().subscribe((result : MeetingData[])=>{
        console.log("inviti accettati", result);
        this.data = result;
        this.changeDetectorRef.detectChanges();
      });
  }

  action(action : string, item: MeetingData): void {
      if(action === "detail"){
        this.openDialog(MeetingDetailComponent, item.id);
      }
  }

  openDialog(component: ComponentType<unknown>, id : number): void {

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data = {id: id};

    const dialogRef = this.dialog.open(component, dialogConfig);

    dialogRef.afterClosed().subscribe((result : BookingData) => {
      console.log('form closed');
      //console.log("result=", result);
      if(result === undefined){
        //console.log('lista chiusa');
        return;
      }
    });
  }

}
