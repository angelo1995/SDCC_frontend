import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output, type OnInit } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MeetingData } from 'src/app/data/MeetingData';

export interface Button {
  name: string;
  action: string;
  color: string;
}

@Component({
  selector: 'app-single-reservation',
  standalone: true,
  imports: [
    CommonModule,
    MatButtonModule,
  ],
  templateUrl: './SingleReservation.component.html',
  styleUrl: './SingleReservation.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SingleReservationComponent implements OnInit {

  @Input()
  meeting!: MeetingData;

  @Input()
  buttons!: Button[];

  @Output()
  actionEmitter : EventEmitter<string> = new EventEmitter<string>();

  constructor(){}

  ngOnInit(): void {
    // Aggiungi l'offset del fuso orario locale
    console.log("input pass", this.meeting);
    const day = new Date(this.meeting.date);
    const timezoneOffset = day.getTimezoneOffset() * 60000;
    const localTime = new Date(day.getTime() + timezoneOffset);
    this.meeting.date = localTime;
  }

  click(action: string): void {
    console.log(this.meeting);
    this.actionEmitter.emit(action);
  }

}
