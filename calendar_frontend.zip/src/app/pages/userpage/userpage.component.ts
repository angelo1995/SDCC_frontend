import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, type OnInit } from '@angular/core';
import { AuthService } from 'src/app/auth/Auth.service';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatListModule} from '@angular/material/list';
import { RouterModule, RouterOutlet } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';

@Component({
    selector: 'app-userpage',
    standalone: true,
    templateUrl: './userpage.component.html',
    styleUrls: ['./userpage.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    imports: [
        CommonModule,
        MatSidenavModule,
        MatListModule,
        RouterOutlet,
        MatButtonModule,
        RouterModule
    ]
})
export class UserpageComponent implements OnInit {

  adminView : boolean = false;

  constructor(private auth: AuthService){}

  ngOnInit(): void {
    if(this.auth.isLoggedIn === false) {
      return; //messaggio di errore
    }
    this.adminView = this.auth.isUserAdmin();
  }

}
