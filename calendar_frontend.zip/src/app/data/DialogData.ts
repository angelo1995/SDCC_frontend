export interface DialogData {
  day: Date;
  duration: number;
  message: string;
  success: boolean;
  description: string;
}
