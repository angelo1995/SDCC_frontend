export class Costumer {

  constructor(
    public id: number,
    public email: string,
    public name: string,
    public surname: string,
    public password: string
  ) { }

}
