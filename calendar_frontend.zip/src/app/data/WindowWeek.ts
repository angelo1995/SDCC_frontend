import { WeekResponse } from "./WeekResponse";

export interface WindowWeek {
  weeks: WeekResponse[][];
}
