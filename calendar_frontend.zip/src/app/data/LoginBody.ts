export interface LoginBody {
  email: string;
  password: string;
 }
