export interface ViewMeeting {
  id: number;
  title: string;
}
