import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, throwError } from 'rxjs';
import { WeekResponse } from '../data/WeekResponse';
import { KeycloakService } from 'keycloak-angular';
import { KeycloakProfile } from 'keycloak-js';
import { OccasionInterface } from '../data/OccasionInterface';
import { Message } from '../data/Message';
import { OccasionCreationInterface } from '../data/OccasionCreationInterface';
import { ViewMeeting } from '../data/viewMeeting';
import { BookingData } from '../data/BookingData';
import { DialogData } from '../data/DialogData';
import { MeetingData } from '../data/MeetingData';

interface ReservationMessage {
  reservation: Reservation;
}

interface Reservation{
  date: Date;
  duration: number;
  description: string;
}

const URL : string = "http://localhost:4200";
//const BACKEND_URL : string = "http://localhost:8081";
const BACKEND_URL : string = "/api";

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  public userProfile: KeycloakProfile | null = null;
  public isLoggedIn = false;

  constructor(private http: HttpClient, private readonly keycloak: KeycloakService) { }

  login(url: string) : void {
    this.keycloak.login({redirectUri: URL+url}).then();
  }

  async isLogged() : Promise<boolean> {
    this.isLoggedIn = await this.keycloak.isLoggedIn();
    if (this.isLoggedIn) {
      this.userProfile = await this.keycloak.loadUserProfile();
    }
    return this.isLoggedIn;
  }

  getUsername(): string {
    return this.userProfile?.username as string;
  }

  logout() : void {
    this.keycloak.logout(URL).then();
  }

  isUserRole(): boolean {
    return this.keycloak.getUserRoles().includes("user");
  }

  isUserAdmin(): boolean {
    return this.keycloak.getUserRoles().includes("admin");
  }

  private printRole(): void {
    console.log(this.keycloak.getUserRoles());
  }

  booking(message: DialogData) : Observable<{}>{
    if(!this.isLoggedIn){
      const observer = new Observable<{}>(observer => {
        const result = {success: false, message: "Per effettuare la prenotazione bisogna eseguire il login"};
        observer.next(result);
        observer.complete();
      });
      return observer;
    }
    const urlLogin = BACKEND_URL + "/book/meeting";
    const reservation : Reservation = {
      date: message.day,
      duration: message.duration,
      description: message.description,
    };
    //const body : ReservationMessage = {reservation: reservation};
    console.log(reservation);
    const  observer : Observable<{}> = this.http.post(urlLogin, reservation/*, this.httpOptions*/)
      .pipe(catchError(this.handleError));
    return observer;
  }

  viewBooking() : Observable<WeekResponse[]>{
    const urlLogin = BACKEND_URL + "/book/view/meeting";
    const  observer : Observable<WeekResponse[]> = this.http.get<WeekResponse[]>(urlLogin,/*, this.httpOptions*/);
    return observer;
  }

  viewBookingWindow(start: Date, end: Date) : Observable<{}>{
    const urlLogin = BACKEND_URL + "/book/view/meeting";
    const body = {start: start, end: end};
    const  observer : Observable<{}> = this.http.post<{}>(urlLogin, body/*, this.httpOptions*/);
    return observer;
  }

  viewAllOccasions() : Observable<OccasionInterface[]> {
    const urlLogin = BACKEND_URL + "/event/view/allEvents";
    const  observer : Observable<OccasionInterface[]> = this.http.get<OccasionInterface[]>(urlLogin);
    return observer;
  }

  getHomeMessage(): Observable<Message> {
    const urlLogin = BACKEND_URL + "/message/home";
    const  observer : Observable<Message> = this.http.get<Message>(urlLogin);
    return observer;
  }

  getAboutUsMessage(): Observable<Message> {
    const urlLogin = BACKEND_URL + "/message/aboutUs";
    const  observer : Observable<Message> = this.http.get<Message>(urlLogin);
    return observer;
  }

  viewUserReservation() : Observable<MeetingData[]> {
    const url = BACKEND_URL + "/book/view/meeting";
    const  observer : Observable<MeetingData[]> = this.http.get<MeetingData[]>(url);
    return observer;
  }

  viewAllReservationAdmin() : Observable<{}> {
    const url = BACKEND_URL + "/admin/all/meeting";
    return this.http.get<{}>(url);
  }

  cancelMeeting(id: number): Observable<{}>  {
    const url = BACKEND_URL + "/book/cancel/"+id;
    return this.http.delete<{}>(url);
  }

  deleteMeeting(id: number): Observable<{}>  {
    const url = BACKEND_URL + "/book/invitation/delete/"+id;
    return this.http.delete<{}>(url);
  }

  private handleError(error: HttpErrorResponse) {
    if (error.status === 0) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong.
      console.error(
        `Backend returned code ${error.status}, body was: `, error.error);
    }
    // Return an observable with a user-facing error message.
    //return throwError(() => new Error('Something bad happened; please try again later.'));
    const observer = new Observable<{}>(observer => {
      const result = {success: false, message: error.error};
      observer.next(result);
      observer.complete();
    });
    return observer;
  }

  createOccasion(body : OccasionCreationInterface): Observable<{}> {
    const url = BACKEND_URL + "/admin/event/new";
    const  observer : Observable<{}> = this.http.post<{}>(url, body);
    return observer;
  }

  viewAllOccasionAdmin() : Observable<{}> {
    const url = BACKEND_URL + "/admin/all/events";
    return this.http.get<{}>(url);
  }

  deleteOccasion(id: number): Observable<{}> {
    const url = BACKEND_URL + "/admin/delete/event/"+id;
    return this.http.delete<{}>(url);
  }

  getAllMeetingsOnSlot() : Observable<{}> {
    //TODO
    const url = BACKEND_URL + "/book/view/slot";
    return this.http.get<{}>(url);
  }

  viewMeetingDetail(id: number) : Observable<{}> {
    const url = BACKEND_URL + "/book/view/meeting/detail/"+id;
    return this.http.get<{}>(url);
  }

  viewMeetingsSlot(body : any) : Observable<ViewMeeting[]> {
    const url = BACKEND_URL + "/book/view/meetings/slot";
    return this.http.post<ViewMeeting[]>(url, body);
  }

  viewAllCostumer() : Observable<{}> {
    const url = BACKEND_URL + "/costumer/view/all";
    return this.http.get<{}>(url);
  }

  bookingMeeting(body: BookingData) : Observable<{}> {

    // Aggiungi l'offset del fuso orario locale
    console.log("time zone", body.date.getTimezoneOffset());
    const timezoneOffset = body.date.getTimezoneOffset() * 60000;
    const localTime = new Date(body.date.getTime() - timezoneOffset);
    body.date = localTime;

    const url = BACKEND_URL + "/book/meeting";
    const  observer : Observable<{}> = this.http.post(url, body)
      .pipe(catchError(this.handleError));
    return observer;
    //return this.http.post<{}>(url, body);
  }

  viewUserInvitations() :  Observable<MeetingData[]> {
    const url = BACKEND_URL + "/book/view/invitations";
    return this.http.get<MeetingData[]>(url);
  }

  viewUserInvitationsAccepted() :  Observable<MeetingData[]> {
    const url = BACKEND_URL + "/book/view/accepted";
    return this.http.get<MeetingData[]>(url);
  }

  viewUserInvitationsRefused() :  Observable<MeetingData[]> {
    const url = BACKEND_URL + "/book/view/refused";
    return this.http.get<MeetingData[]>(url);
  }

  invitationAccept(id : number) :  Observable<boolean> {
    const url = BACKEND_URL + "/book/invitation/accept/"+id;
    return this.http.get<boolean>(url);
  }

  invitationRefuse(id : number) :  Observable<boolean> {
    const url = BACKEND_URL + "/book/invitation/refuse/"+id;
    return this.http.get<boolean>(url);
  }

}
