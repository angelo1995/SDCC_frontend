import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, type OnInit } from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {MatButtonModule} from '@angular/material/button';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatTabsModule} from '@angular/material/tabs';
import { ThemePalette } from '@angular/material/core';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../auth/Auth.service';
import { Costumer } from '../data/Costumer';

@Component({
  selector: 'app-navigation-bar',
  standalone: true,
  imports: [
    CommonModule,
    MatToolbarModule, MatButtonModule, MatIconModule, MatTabsModule,
    RouterModule
  ],
  templateUrl: './NavigationBar.component.html',
  styleUrls: ['./NavigationBar.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class NavigationBarComponent implements OnInit {

  isLogged : boolean = false;

  username : string = "";

  constructor(
    private auth: AuthService,
    private changeDetectorRef: ChangeDetectorRef,
    private router: Router
    ){}

  ngOnInit(): void {
    this.auth.isLogged().then((isLoggedIn) => {
      this.isLogged = isLoggedIn;
      if(this.isLogged){
        this.username = this.auth.getUsername();
        this.changeDetectorRef.detectChanges(); //fa il refresh del componente
      }
    });
  }

  links = ['First', 'Second', 'Third'];
  activeLink = this.links[0];
  background: ThemePalette = undefined;

  toggleBackground() {
    //this.background = this.background ? undefined : 'primary';
  }

  addLink() {
    this.links.push(`Link ${this.links.length + 1}`);
  }

  onLog(event : any){
    console.log(event);
  }

  logout() : void {
    this.auth.logout();
    this.router.navigateByUrl('/home');
  }

  login(): void {
    this.auth.login(this.router.url);
  }

}
