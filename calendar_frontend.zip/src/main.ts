import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';


import { APP_INITIALIZER, importProvidersFrom } from '@angular/core';
import { AppComponent } from './app/app.component';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { withInterceptorsFromDi, provideHttpClient } from '@angular/common/http';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { provideAnimations } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app/app-routing.module';
import { BrowserModule, bootstrapApplication } from '@angular/platform-browser';
import { DatePipe } from '@angular/common';
import { MAT_DIALOG_DATA, MatDialogRef, MAT_DIALOG_DEFAULT_OPTIONS, MatDialogModule } from '@angular/material/dialog';
import { KeycloakAngularModule, KeycloakEventType, KeycloakService } from 'keycloak-angular';
import {MatAutocompleteModule} from '@angular/material/autocomplete';

function initializeKeycloak(keycloak: KeycloakService) {
  keycloak.keycloakEvents$.subscribe({
    next(event : any) {
      if (event.type == KeycloakEventType.OnTokenExpired) {
        keycloak.updateToken(20);
      }
    }
  });

  return () =>
    keycloak.init({
      config: {
        url: 'http://localhost:8080',
        realm: 'calendar',
        clientId: 'login-app'
      },
      initOptions: {
        onLoad: 'check-sso',
        //silentCheckSsoRedirectUri:
          //window.location.origin + '/assets/silent-check-sso.html'
      }
    });
}

bootstrapApplication(AppComponent, {
    providers: [
        importProvidersFrom(BrowserModule, AppRoutingModule, MatToolbarModule, MatIconModule, MatButtonModule, FormsModule, ReactiveFormsModule, RouterModule, MatFormFieldModule, MatSelectModule, MatDialogModule, MatSnackBarModule, KeycloakAngularModule, MatAutocompleteModule),
        { provide: MAT_DIALOG_DATA, useValue: {} },
        { provide: MatDialogRef, useValue: {} },
        { provide: MAT_DIALOG_DEFAULT_OPTIONS, useValue: { hasBackdrop: false } },
        {
          provide: APP_INITIALIZER,
          useFactory: initializeKeycloak,
          multi: true,
          deps: [KeycloakService]
        },
        DatePipe,
        provideAnimations(),
        provideHttpClient(withInterceptorsFromDi())
    ]
})
  .catch(err => console.error(err));
