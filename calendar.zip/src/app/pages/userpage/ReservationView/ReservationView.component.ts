import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, type OnInit } from '@angular/core';
import { AuthService } from 'src/app/auth/Auth.service';
import { Button, SingleReservationComponent } from "./SingleReservation/SingleReservation.component";
import { MeetingData } from 'src/app/data/MeetingData';
import { DETAIL_COLOR, WARN_COLOR } from 'src/app/data/Color';
import { ComponentType } from '@angular/cdk/portal';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { BookingData } from 'src/app/data/BookingData';
import { MeetingDetailComponent } from '../../Calendar/component/MeetingDetail/MeetingDetail.component';

@Component({
    selector: 'app-reservation-view',
    standalone: true,
    templateUrl: './ReservationView.component.html',
    styleUrl: './ReservationView.component.css',
    changeDetection: ChangeDetectionStrategy.OnPush,
    imports: [
        CommonModule,
        SingleReservationComponent
    ]
})
export class ReservationViewComponent implements OnInit {

  data : MeetingData[] = [];

  buttons : Button[] = [{name: "dettagli", action: "detail", color: DETAIL_COLOR}, {name: "annulla", action: "cancel", color: WARN_COLOR}];

  //adminView : boolean = true;

  constructor(private auth: AuthService, public dialog: MatDialog, private changeDetectorRef: ChangeDetectorRef){}

  ngOnInit(): void {
    /*this.adminView = this.auth.isUserAdmin();

    if(this.adminView === true){
      this.auth.viewAllReservationAdmin().subscribe((result : any)=>{
        console.log(result);
        this.data = result;
        this.changeDetectorRef.detectChanges();
      });
    } else {
      this.auth.viewUserReservation().subscribe((result : any)=>{
        console.log(result);
        this.data = result;
        this.changeDetectorRef.detectChanges();
      });
    }*/
      this.auth.viewUserReservation().subscribe((result : MeetingData[])=>{
        console.log(result);
        this.data = result;
        this.changeDetectorRef.detectChanges();
      });
  }

  action(action : string, item: MeetingData): void {
    if(action === "cancel"){
      this.auth.cancelMeeting(item.id).subscribe((result : any)=>{
        console.log(result);
        if(result === true){
          const index : number = this.data.indexOf(item);
          this.data.splice(index, 1);
          this.changeDetectorRef.detectChanges();
        }
      });
    }

    if(action === "detail"){
      this.openDialog(MeetingDetailComponent, item.id);
    }
  }

  openDialog(component: ComponentType<unknown>, id : number): void {

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data = {id: id};

    const dialogRef = this.dialog.open(component, dialogConfig);

    dialogRef.afterClosed().subscribe((result : BookingData) => {
      console.log('form closed');
      //console.log("result=", result);
      if(result === undefined){
        //console.log('lista chiusa');
        return;
      }
    });
  }

}
