import { ComponentType } from '@angular/cdk/portal';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, type OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { AuthService } from 'src/app/auth/Auth.service';
import { BookingData } from 'src/app/data/BookingData';
import { PRIMARY_COLOR, DETAIL_COLOR, WARN_COLOR } from 'src/app/data/Color';
import { MeetingData } from 'src/app/data/MeetingData';
import { MeetingDetailComponent } from '../../Calendar/component/MeetingDetail/MeetingDetail.component';
import { Button, SingleReservationComponent } from "../ReservationView/SingleReservation/SingleReservation.component";

@Component({
  selector: 'app-invitation-accepted',
  standalone: true,
  imports: [
    CommonModule,
    SingleReservationComponent,
  ],
  templateUrl: './InvitationAccepted.component.html',
  styleUrl: './InvitationAccepted.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class InvitationAcceptedComponent implements OnInit {

  data : MeetingData[] = [];

  buttons : Button[] = [
    {name: "dettagli", action: "detail", color: DETAIL_COLOR},
  ];

  buttonsCancelled : Button[] = [
    {name: "dettagli", action: "detail", color: DETAIL_COLOR},
    {name: "cancella", action: "delete", color: WARN_COLOR},
  ];

  constructor(private auth: AuthService, public dialog: MatDialog, private changeDetectorRef: ChangeDetectorRef){}

  ngOnInit(): void {
      this.auth.viewUserInvitationsAccepted().subscribe((result : MeetingData[])=>{
        console.log("inviti accettati", result);
        this.data = result;
        this.changeDetectorRef.detectChanges();
      });
  }

  action(action : string, item: MeetingData): void {
      if(action === "detail"){
        this.openDialog(MeetingDetailComponent, item.id);
      }
      if(action === "delete"){
        this.auth.deleteMeeting(item.id).subscribe((result : any)=>{
          console.log(result);
          if(result === true){
            const index : number = this.data.indexOf(item);
            this.data.splice(index, 1);
            this.changeDetectorRef.detectChanges();
          }
        });
      }
  }

  openDialog(component: ComponentType<unknown>, id : number): void {

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data = {id: id};

    const dialogRef = this.dialog.open(component, dialogConfig);

    dialogRef.afterClosed().subscribe((result : BookingData) => {
      console.log('form closed');
      //console.log("result=", result);
      if(result === undefined){
        //console.log('lista chiusa');
        return;
      }
    });
  }

}
