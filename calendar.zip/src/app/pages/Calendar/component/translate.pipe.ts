import { Pipe, type PipeTransform } from '@angular/core';

@Pipe({
  name: 'appTranslate',
  standalone: true,
})
export class TranslatePipe implements PipeTransform {

  transform(value: string): string {
    if(value === "occupied"){
      return "riunione";
    }
    return value;
  }

}
