import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, type OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import {MatTableModule} from '@angular/material/table';
import { TranslatePipe } from '../translate.pipe';
import { AuthService } from 'src/app/auth/Auth.service';
import { Observable } from 'rxjs';
import {MatSnackBar} from '@angular/material/snack-bar';
import { DataTableService } from '../DataTable.service';
import { MeetingListComponent } from '../MeetingList/MeetingList.component';
import { DialogData } from 'src/app/data/DialogData';

export interface DayOfWeek {
  position: number;
  hour: string;
  monday: string;
  tuesday: string;
  wednesday: string;
  thursday: string;
  friday: string;
  saturday: string;
}

const PLACE_HOLDER_WEEK: DayOfWeek[] = [
  {position: 0, hour: '08:00', monday: '', tuesday: '', wednesday: '', thursday: '', friday: '', saturday: 'occupied'},
  {position: 1, hour: '09:00', monday: '', tuesday: '', wednesday: '', thursday: '', friday: '', saturday: 'occupied'},
  {position: 2, hour: '10:00', monday: '', tuesday: '', wednesday: '', thursday: '', friday: '', saturday: 'occupied'},
  {position: 3, hour: '11:00', monday: '', tuesday: '', wednesday: '', thursday: '', friday: '', saturday: ''},
  {position: 4, hour: '12:00', monday: '', tuesday: '', wednesday: '', thursday: '', friday: '', saturday: ''},
  {position: 5, hour: '13:00', monday: 'occupied', tuesday: '', wednesday: '', thursday: '', friday: '', saturday: ''},
  {position: 6, hour: '14:00', monday: '', tuesday: '', wednesday: '', thursday: '', friday: '', saturday: ''},
  {position: 7, hour: '15:00', monday: '', tuesday: '', wednesday: '', thursday: '', friday: '', saturday: ''},
  {position: 8, hour: '16:00', monday: '', tuesday: '', wednesday: '', thursday: '', friday: '', saturday: ''},
  {position: 9, hour: '17:00', monday: '', tuesday: '', wednesday: '', thursday: '', friday: '', saturday: ''},
  {position: 10, hour: '18:00', monday: '', tuesday: '', wednesday: '', thursday: '', friday: '', saturday: ''},
];

@Component({
  selector: 'app-weekly-calendar',
  standalone: true,
  imports: [
    CommonModule, MatTableModule, TranslatePipe
  ],
  templateUrl: './weeklyCalendar.component.html',
  styleUrls: ['./weeklyCalendar.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WeeklyCalendarComponent implements OnInit {

  displayedColumns: string[] = ['hour', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];

  dataSource : DayOfWeek[] = PLACE_HOLDER_WEEK;

  @Input()
  day: Date = new Date("2024-01-15");

  constructor(
    private auth: AuthService,
    public dialog: MatDialog,
    private _snackBar: MatSnackBar,
    private changeDetectorRef: ChangeDetectorRef,
    private dataService: DataTableService
    ) {}

  onClickCell(row: number, column: string): void{
    if(row < 0){
      return;
    }
    const element: DayOfWeek = this.dataSource[row];
    const item = element[column as keyof DayOfWeek];
    const offset = this.displayedColumns.findIndex((day)=>day === column) - 1;
    const day : Date = this.createDay(row, offset);

    if(this.isLate(row, column)){
      this.openSnackBar("Non puoi prenotare nelle ore passate", "ok", 2500);
      return;
    }

    //booking
    this.openDialog(day);
  }

  ngOnInit(): void {
    this.dataService.consume().subscribe((data)=> {
      this.dataSource = [];
      this.dataSource = data;
      console.log("dataSource", this.dataSource);
      this.changeDetectorRef.detectChanges();
    });
    return;
    /*
    this.auth.viewBooking().subscribe((response : WeekResponse[]) => {
      this.dataSource = [];
      let row : DayOfWeek = {position: -1, hour: '', monday: '', tuesday: '', wednesday: '', thursday: '', friday: '', saturday: ''};
      for(let i : number = 0; i < 11; i++){
        row = {
          position: i,
          hour: (i+8)+':00',
          monday: response[i].monday,
          tuesday: response[i].tuesday,
          wednesday: response[i].wednesday,
          thursday: response[i].thursday,
          friday: response[i].friday,
          saturday: response[i].saturday
        };
        this.dataSource.push(row);
      }
      this.changeDetectorRef.detectChanges();
    });*/
  }

  openDialog(day : Date): void {

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data = {day: day};

    /*
    const dialogRef = this.dialog.open(BookingFormComponent, {
      data: {name: this.name, animal: this.animal, person: this.person},
      //width: '500px', height: '500px'
    });*/

    if(this.auth.isLoggedIn !== true){
      this.openSnackBar("Bisogna fare il login per la prenotazione", "ok", 3500);
      return;
    }

    const dialogRef = this.dialog.open(MeetingListComponent, dialogConfig);

    dialogRef.afterClosed().subscribe((result : DialogData) => {
      //console.log('The dialog was closed');
      //console.log("result=", result);
      if(result === undefined){
        //console.log('booking cancelled');
        this.openSnackBar("prenotazione annullata", "ok");
        return;
      }
      const duration = result.duration;
      //const observer : Observable<{}> = this.auth.booking(result);
      //observer.subscribe((result : any) => {
        console.log("reservation response serve", result);
        //this.openSnackBar(result.message, "ok", 2*1000);
        if(result.success === true){
          const dayString = this.displayedColumns[day.getDay()];
          this.setOccupied(dayString, day.getHours(), duration);
          this.changeDetectorRef.detectChanges();
        }
      //});
    });
  }

  private setOccupied(dayString: string, start: number, duration: number): void {
    for(let i=0; i < duration; i++){
      const dayOfWeek : DayOfWeek = this.dataSource[start-8+i];
      /*
      dayOfWeek[dayString]='occupied';
      dayOfWeek[dayString as keyof DayOfWeek]='occupied';
      */
      switch(dayString){
        case 'monday':
          dayOfWeek.monday = 'occupied';
        break;
        case 'tuesday':
          dayOfWeek.tuesday = 'occupied';
          break;
        case 'wednesday':
          dayOfWeek.wednesday = 'occupied';
        break;
        case 'thursday':
          dayOfWeek.thursday = 'occupied';
        break;
        case 'friday':
          dayOfWeek.friday = 'occupied';
        break;
        case 'saturday':
          dayOfWeek.saturday = 'occupied';
        break;
      }
    }
  }

  isLate(row: number, column : string) : boolean {
    const offset = this.displayedColumns.findIndex((day)=>day === column) - 1;
    const today : Date = new Date();
    const day : Date = this.createDay(row, offset);
    if(row == -1){
      return false;
    }
    return day.getTime() < today.getTime();
  }

  private createDay(hour: number, offset: number) : Date {
    const newDay = this.day.getTime() + offset*(1000 * 60 * 60 * 24);
    const day = new Date(newDay);
    day.setHours(8+hour);
    day.setMinutes(0);
    day.setSeconds(0);
    day.setMilliseconds(0);

    // Aggiungi l'offset del fuso orario locale
    //console.log("time zone", day.getTimezoneOffset());
    //const timezoneOffset = day.getTimezoneOffset() * 60000;
    //const localTime = new Date(day.getTime() - timezoneOffset);
    return day;
  }

  dayWeek(offset: number) : Date {
    const newDay = this.day.getTime() + offset*(1000 * 60 * 60 * 24);
    return new Date(newDay);
  }

  private openSnackBar(message: string, action: string, durationInMillisecond?: number) {
    if(durationInMillisecond === undefined){
      this._snackBar.open(message, action);
    }
    this._snackBar.open(message, action, {
      duration: durationInMillisecond,
    });
  }

}
