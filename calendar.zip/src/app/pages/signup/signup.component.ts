import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, type OnInit } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import {MatInputModule} from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';
import { FormsModule, NgForm } from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import { AuthService } from 'src/app/auth/Auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [
    CommonModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    MatButtonModule,
    FormsModule,
    MatIconModule,
  ],
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SignupComponent implements OnInit {

  hide = true;

  constructor(private auth: AuthService, private router: Router){}

  ngOnInit(): void { }

  onSubmit(form: NgForm){
    /*
    const email = form.value.email;
    const password = form.value.password;
    const name = form.value.name;
    const surname = form.value.surname;
    const phone = form.value.cellNumber;
    const body = {
      name: name,
      surname: surname,
      email: email,
      password: password,
      phone: phone
    };
    console.log(email, password);
    console.log("phone: ", phone);
    /*form.reset(); it is possible to reset the form*/
    /*const response = this.auth.signup(body);
    response.subscribe((risposta) => {
      console.log(risposta);
      if(risposta.success){
        this.router.navigateByUrl('/home');
      }
    });*/
  }

}
