export interface BookingData {

	title : string;
	description : string;
	date: Date;
  duration: number;
  priority: string;
  guests: number[];
}
