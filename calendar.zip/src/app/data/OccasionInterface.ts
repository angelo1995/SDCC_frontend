export interface OccasionInterface {
  title: string;
  description: string;
  date: Date;
  like: number;
  dislike: number;
  attendance: number; //presenze
  price: number;
  id: number;
}
