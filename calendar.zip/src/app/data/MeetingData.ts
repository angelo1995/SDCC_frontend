export interface MeetingData {
  id: number;
  title: string;
  description: string;
  date: Date;
  duration: number;
  cancelled: boolean;
}
