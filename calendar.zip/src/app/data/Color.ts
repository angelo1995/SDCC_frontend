export const PRIMARY_COLOR = "#3f51b5";
export const WARN_COLOR = "#f44336";
export const ACCENT_COLOR = "#ff4081";

export const DETAIL_COLOR = "#168b85";
