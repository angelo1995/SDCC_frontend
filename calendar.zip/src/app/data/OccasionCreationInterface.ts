export interface OccasionCreationInterface {
  title: string;
  description: string;
  date: Date;
  price: number;
  duration: number;
}
