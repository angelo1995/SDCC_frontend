import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './pages/Home/Home.component';
import { CalendarComponent } from './pages/Calendar/Calendar.component';
import { AboutUsComponent } from './pages/AboutUs/AboutUs.component';
import { LoginPageComponent } from './pages/LoginPage/LoginPage.component';
import { LogoutPageComponent } from './pages/LogoutPage/LogoutPage.component';
import { SignupComponent } from './pages/signup/signup.component';
import { PageNotFoundComponent } from './pages/PageNotFound/PageNotFound.component';
import { UserpageComponent } from './pages/userpage/userpage.component';
import { OccasionViewComponent } from './pages/userpage/OccasionView/OccasionView.component';
import { ReservationViewComponent } from './pages/userpage/ReservationView/ReservationView.component';
import { InvitationComponent } from './pages/userpage/Invitation/Invitation.component';
import { InvitationAcceptedComponent } from './pages/userpage/InvitationAccepted/InvitationAccepted.component';
import { RefuseInvitationComponent } from './pages/userpage/RefuseInvitation/RefuseInvitation.component';

const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    redirectTo: '/home'
  },
  {
    path: 'userPage',
    pathMatch: 'full',
    redirectTo: '/userPage/reservation'
  },
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: 'booking',
    component: CalendarComponent
  },
  {
    path: 'about-us',
    component: AboutUsComponent
  },
  {
    path: 'notifications',
    component: UserpageComponent,
    children: [
      {path: 'created', component: ReservationViewComponent},
      {path: 'invitations', component: InvitationComponent},
      {path: 'accepted', component: InvitationAcceptedComponent},
      {path: 'rejected', component: RefuseInvitationComponent},
    ]
  },
  {
    path: 'login',
    component: LoginPageComponent
  },
  {
    path: 'signup',
    component: SignupComponent
  },
  {
    path: 'logout',
    component: LogoutPageComponent
  },
  {
    path: 'pageNotFound',
    component: PageNotFoundComponent
  },
  {
    path: '**',
    redirectTo: '/pageNotFound'
  },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
